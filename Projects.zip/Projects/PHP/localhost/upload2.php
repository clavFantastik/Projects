<?php
$tit = $_REQUEST['title'];

$name = $_FILES['userfile']['name'];
if (move_uploaded_file($_FILES['userfile']['tmp_name'], 'files/' . $_FILES['userfile']['name'])) {
    $db = new PDO('mysql:host=localhost;dbname=bd', 'root', '');
    $req = $db->prepare("INSERT INTO `files`(name,src) values ('$tit','files/$name')");
    $req->execute();

    header('Location: index.php', true, 301);
}

?>


<!doctype html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/main.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <title>File Upload</title>
    <link href="css/form.css" rel="stylesheet">


</head>

<body class="text-center">
    <header class="main-header">
        <div class="container">
            <a href="index.php" style="text-decoration: none;color:white">
                <h1>OwnCloud</h1>
            </a>
        </div>
    </header>
    <main>
        <div class="container">
            <form class="form-signin" action="" method="POST" enctype="multipart/form-data">
                <h1 class="h3 mb-3 font-weight-normal">Загрузите файл</h1>

                <input name="title" type="text" class="form-control" placeholder="Введите имя файла" required>
                <input name="userfile" type="file" class="form-control" placeholder="Выберите файл" required>

                <br>

                <button class="btn btn-lg btn-primary btn-block" type="submit">Отправить</button>
            </form>
        </div>
    </main>
</body>

</html>