<?php


function render($replaces, $tpl_filename)
{
    $tpl = file_get_contents($tpl_filename);
    $tpl = strtr($tpl, $replaces);
    return $tpl;
}
$db = new PDO('mysql:host=localhost;dbname=bd', 'root', '');
$req = $db->prepare("SELECT * FROM `files` WHERE 1");
$req->execute();
$responceArr = $req->fetchall(PDO::FETCH_ASSOC);
$article = '';
foreach ($responceArr as $val) {
    $vv = explode(".", $val['src'])[1];
    $inf = $val['src'];
    if ($vv == "zip") {
        $fold = 'img/icons/icons8-archive-folder-100.png';
    }
    if ($vv == "jpeg" or $vv == "jpg") {
        $fold = 'img/icons/icons8-jpg-100.png';
    }
    if ($vv == "png") {
        $fold = 'img/icons/icons8-png-100.png';
    }
    if ($vv == "pdf") {
        $fold = 'img/icons/icons8-pdf-100.png';
    }
    if ($vv == "gif") {
        $fold = 'img/icons/icons8-gif-100.png';
    }
    if ($vv == "doc" or $vv == "docx") {
        $fold = 'img/icons/icons8-microsoft-word-100.png';
    }
    if ($vv == "xml" or $vv == "txt") {
        $fold = 'img/icons/icons8-microsoft-excel-100.png';
    }
    if ($vv == "mp3") {
        $fold = 'img/icons/icons8-audio-file-100.png';
    }
    if ($vv == "mp4") {
        $fold = 'img/icons/icons8-video-file-100.png';
    }
    if ($vv == "ppt" or $vv == "pptx" or $vv == "rtf") {
        $fold = 'img/icons/icons8-video-file-100.png';
    }
    if ($vv == "exe") {
        $fold = 'img/icons/exe-png.png';
    }
    if ($vv == "css") {
        $fold = 'img/icons/cs2s.png';
    }
    if ($vv == "py") {
        $fold = 'img/icons/py.png';
    }
    if ($vv == "html" or $vv == "htm") {
        $fold = 'img/icons/html.png';
    }
    if ($vv == "php") {
        $fold = 'img/icons/php.png';
    }
    if ($vv == "js") {
        $fold = 'img/icons/js.png';
    }
    $data = array(
        '{{name}}' => $val['name'],
        '{{ext}}' =>  $vv,
        '{{fifo}}' => $fold,
        '{{inf}}' => $inf,
        '{{id}}' => $val['id']

    );
    $article .= render($data, 'good.html');
}
$data2 = array(
    '{{filees}}' => $article
);

echo render($data2, 'index.html');
