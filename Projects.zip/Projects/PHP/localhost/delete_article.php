<?php

$id = $_REQUEST['id'];

$db = new PDO('mysql:host=localhost;dbname=bd', 'root', '');
$ps = $db->prepare("DELETE FROM `files` WHERE `id` = $id");
$ps->execute();

header('Location: index.php', true, 301);
