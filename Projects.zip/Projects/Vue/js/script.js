'use strict';

const vm = new Vue({
    el: "#app",
    data: {
        cardNum: '',
        isActive: false,
        nameOfPers: '',
        coloray: '#eff5f8'
    },

    computed: {
        card() {
            let a = this.cardNum[0];
            if (a == 2) {
                return "img/systems/mir.png";
            } else if (a == 3) {
                return "img/systems/american-exp.png";
            } else if (a == 4) {
                return "img/systems/visa.png";
            } else if (a == 5) {
                return "img/systems/mastercard.png";
            } else if (a == 6) {
                return "img/systems/maestro.png";
            }
        },
        obj() {
            let a = this.cardNum;
            if (a.length == 16) {
                const isLuhnValid = function luhn(array) {
                    return function (number) {
                        let len = number ? number.length : 0,
                            bit = 1,
                            sum = 0;

                        while (len--) {
                            sum += !(bit ^= 1) ? parseInt(number[len], 10) : array[number[len]];
                        }

                        return sum % 10 === 0 && sum > 0;
                    };
                }([0, 2, 4, 6, 8, 1, 3, 5, 7, 9]);

                return isLuhnValid(a.split(""));
            } else {
                return false;
            }
        }, obj2() {
            let a = this.nameOfPers;
            let c2 = 0;
            let count = 0;
            let c = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
            for (let i in a) {
                let pos = c.indexOf(a[i]);
                if (pos == -1) {
                    c2 += 1;
                }
            }
            if (c2 == 0 && a != '') {
                return this.isActive = true;
            } else {
                return this.isActive = false;
            }

        },
        banka() {
            let b = this.cardNum.substring(0, 6);

            if (b == 521178 || b == 548673 || b == 548601 || b == 415428 || b == 676371 || b == 477964 || b == 479004) {

                return "img/banks/alpha.png";
            }
            else if (b == 427229 || b == 527883 || b == 447520) {

                return "img/banks/vtb.png";
            }
            else if (b == 548999 || b == 526483) {

                return "img/banks/gazprombank.png";
            }
            else if (b == 533736 || b == 540616) {

                return "img/banks/mts-bank.png";
            }
            else if (b == 434146 || b == 405870 || b == 544573 || b == 532301) {

                return "img/banks/otkrytie.png";
            }
            else if (b == 440503 || b == 554761) {

                return "img/banks/rosbank.png";
            }
            else if (b == 513691 || b == 510047) {

                return "img/banks/russian_standart.png";
            }
            else if (b == 462730 || b == 462729) {

                return "img/banks/raiffaizen.png";
            }
            else if (b == 427683 || b == 427901 || b == 427644 || b == 427601 || b == 427631 || b == 427638 || b == 427901 || b == 546938) {

                return "img/banks/sberbank.png";
            }
            else if (b == 521324 || b == 437773) {

                return "img/banks/tinkoff.png";
            }

        }

    }
});