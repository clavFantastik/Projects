'use strict';

window.onscroll = function () {
    myFunction();
};
function myFunction() {
    let winScroll =
        document.body.scrollTop || document.documentElement.scrollTop;
    let height =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;
    let scrolled = (winScroll / height) * 100;
    myBar.style.width = scrolled + "%";
}


let xhr = new XMLHttpRequest();
xhr.open('GET', 'https://api.npoint.io/407fbe7f120a7052c67e', true);
xhr.send();

xhr.addEventListener('readystatechange', function () {
    if (xhr.readyState == 4 && xhr.status == 200) {

        let ordersArr = JSON.parse(xhr.responseText);


        let orderCode = '<tr><td>{{name}}</td><td>{{phone}}</td></tr>';

        let template = Handlebars.compile(orderCode);
        let ordersContainer = document.querySelector('#orderLines');

        ordersContainer.innerHTML = '';

        for (let order of ordersArr) {
            ordersContainer.innerHTML += template(order);
            console.log(template(order));
        }


    }
});