'use strict';
let Tim = setTimeout(function () {
    load.style.display = "block";
}, 1000);
setTimeout(function () {
    load.style.display = "none";
    clearTimeout(Tim);
}, 1000);
let int = 0;
window.onscroll = function () {
    myFunction();
};
function myFunction() {
    let winScroll =
        document.body.scrollTop || document.documentElement.scrollTop;
    let height =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;
    let scrolled = (winScroll / height) * 100;
    myBar.style.width = scrolled + "%";

    if (scrolled >= 70) {
        upper.style.opacity = "1";
    } else {
        upper.style.opacity = "0";
    }
}



let timeOut;
function goUp() {
    let top = Math.max(
        document.body.scrollTop,
        document.documentElement.scrollTop
    );
    if (top > 0) {
        window.scrollBy(0, -100);
        timeOut = setTimeout("goUp()", 30);
    } else clearTimeout(timeOut);
}



function addToCart(title, price, id, count) {
    let cart = [];
    let counter = [];
    let k = 1;

    if ('cart' in localStorage) {
        cart = JSON.parse(localStorage.cart);
    }
    if ('counter' in localStorage) {
        counter = JSON.parse(localStorage.counter);
    }
    console.log(count);
    let prom = JSON.parse(localStorage.getItem('cart'));

    for (let i of prom) {
        if (title == i['title']) {
            k = 0
        }
    }


    if (k != 0) {
        cart.push({
            title: title,
            price: price,
            id: id,
            count: count

        });
        k = 1;
    } else {
        counter.push({
            count: count,
            title: title
        });
        for (let i of cart) {
            if (i.title == title) {
                i.count++;
            }
        }
        console.log(cart);
    }


    localStorage.setItem('cart', JSON.stringify(cart));
    localStorage.setItem('counter', JSON.stringify(counter));


}


let xhrLoadProd = new XMLHttpRequest();
xhrLoadProd.open('GET', 'https://api.npoint.io/ffb62331b1d8fbc9b934', true);
xhrLoadProd.send();

xhrLoadProd.addEventListener('readystatechange', function () {
    if (xhrLoadProd.readyState == 4 && xhrLoadProd.status == 200) {
        let productsArr = JSON.parse(xhrLoadProd.responseText);
        let templateCode = '<div><div div class="uk-card uk-card-default uk-card-body" ><h3 class="uk-card-title">{{title}}</h3><img src="{{img}}"><p>{{description}}</p><footer class="uk-flex uk-flex-between"><span class="uk-text-large uk-text-bold">{{price}} руб</span><button onclick = "' + "car.classList.add('animate__animated');int+=1;car2.innerHTML=int;" + '" class="uk-button uk-button-danger"' + "id='btnBuy' data-title='{{title}}' data-price='{{price}}' data-click='0'" + '  > <span uk-icon="cart"></span></button ></footer ></div ></div >';
        let template = Handlebars.compile(templateCode);

        let productsContainer = document.querySelector('#productsContainer');


        productsContainer.innerHTML = '';


        for (let product of productsArr) {

            productsContainer.innerHTML += template(product);
        }

        let id = 0;
        for (let btn of btnBuy) {
            let count = 0;
            btn.addEventListener('click', function () {
                count += 1;
                addToCart(btn.dataset.title, btn.dataset.price, id, count);
                id += 1;
            });
        }
    }

});




let xhrLoadProd2 = new XMLHttpRequest();
xhrLoadProd2.open('GET', 'https://api.npoint.io/444a2a3af4cf782a472a', true);
xhrLoadProd2.send();

xhrLoadProd2.addEventListener('readystatechange', function () {
    if (xhrLoadProd2.readyState == 4 && xhrLoadProd2.status == 200) {
        let commentArr = JSON.parse(xhrLoadProd2.responseText);

        let commentCode = '<article class="uk-comment" style="position:static"><div header class="uk-comment-header uk-flex uk-flex-middle" ><div class="uk-width-auto"><img class="uk-comment-avatar"src="{{imga}}"width="80" height="80"></div><div class="uk-width-expand"><h4 class="uk-comment-title uk-margin-remove">{{author}}</h4></div></div><div class="uk-comment-body"><p>{{comm}}</p></div></article >';

        let template2 = Handlebars.compile(commentCode);
        let commentsContainer = document.querySelector('#commentsContainer');

        commentsContainer.innerHTML = '';

        for (let comm of commentArr) {
            commentsContainer.innerHTML += template2(comm);
        }
    }
});


document.querySelector('#commBtn').addEventListener('click', function () {
    let xhr2 = new XMLHttpRequest();
    xhr2.open('GET', 'https://api.npoint.io/444a2a3af4cf782a472a', true);
    xhr2.send();

    xhr2.addEventListener('readystatechange', function () {
        if (xhr2.readyState == 4 && xhr2.status == 200) {
            let commentArr = JSON.parse(xhr2.responseText);

            let newOrder2 = {
                imga: 'https://robohash.org/%D0%B8%D0%BC%D1%8F%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F',
                author: commentName.value,
                comm: commaentText.value
            }
            commentArr.push(newOrder2);

            let xhrSender2 = new XMLHttpRequest();
            xhrSender2.open('post', 'https://api.npoint.io/444a2a3af4cf782a472a', true);
            xhrSender2.setRequestHeader('Content-type', 'application/json; charset=utf-8');

            xhrSender2.send(JSON.stringify(commentArr));

            xhrSender2.addEventListener('readystatechange', function () {
                if (xhrSender2.readyState == 4) {
                    if (xhrSender2.status == 200) {
                        alert('Ваш комментарий оставлен успешно!');
                    } else {
                        alert('Произошла ошибка в отправки комментария');
                    }
                }
            })
        }

    });
});


document.querySelector('#sendOrderBtn').addEventListener('click', function () {
    let xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://api.npoint.io/407fbe7f120a7052c67e', true);
    xhr.send();

    xhr.addEventListener('readystatechange', function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let ordersArr = JSON.parse(xhr.responseText);

            let newOrder = {
                name: orderName.value,
                phone: orderField.value
            }
            ordersArr.push(newOrder);

            let xhrSender = new XMLHttpRequest();
            xhrSender.open('post', 'https://api.npoint.io/407fbe7f120a7052c67e', true);

            xhrSender.setRequestHeader('Content-type', 'application/json; charset=utf-8');

            xhrSender.send(JSON.stringify(ordersArr));

            xhrSender.addEventListener('readystatechange', function () {
                if (xhrSender.readyState == 4) {
                    if (xhrSender.status == 200) {
                        alert('Ваша заявка принята. Оператор скоро свяжется с Вами!');
                    } else {
                        alert('Ошибка отправки. Попробуйте еще раз.');
                    }
                }
            })
        }

    });
});
navigator.geolocation.getCurrentPosition(function (position) {
    let geo_xhr = new XMLHttpRequest();
    let geocoder = 'https://geocode-maps.yandex.ru/1.x/?format=json&apikey=a0f4c97d-641f-4a82-861f-e88cccdb49d0&geocode=';
    geocoder += position.coords.longitude;
    geocoder += ',';
    geocoder += position.coords.latitude;

    geo_xhr.open("GET", geocoder, true);
    geo_xhr.send();
    let location = document.querySelector('#location');
    geo_xhr.addEventListener('readystatechange', function () {
        if (geo_xhr.readyState == 4 && geo_xhr.status == 200) {
            let res = JSON.parse(geo_xhr.responseText);
            location.innerHTML = res.response.GeoObjectCollection.featureMember[3].GeoObject.name + ', ' + res.response.GeoObjectCollection.featureMember[1].GeoObject.name;
        }
    });
});


