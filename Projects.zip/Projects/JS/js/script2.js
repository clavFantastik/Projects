
'use strict';

window.onscroll = function () {
    myFunction();
};
function myFunction() {
    let winScroll =
        document.body.scrollTop || document.documentElement.scrollTop;
    let height =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;
    let scrolled = (winScroll / height) * 100;
    myBar.style.width = scrolled + "%";
}

document.querySelector('#addProductBtn').addEventListener('click', function () {
    if (productTitle2.value != '' && productImg.value != '' && productDescription.value != '' && productPrice.value != '') {

        let xhrLoadProd = new XMLHttpRequest();

        xhrLoadProd.open('GET', 'https://api.npoint.io/ffb62331b1d8fbc9b934', true);

        xhrLoadProd.send();

        xhrLoadProd.addEventListener('readystatechange', function () {
            if (xhrLoadProd.readyState == 4 && xhrLoadProd.status == 200) {
                let productsArr = JSON.parse(xhrLoadProd.responseText);



                let newProduct = {
                    title: productTitle2.value,
                    img: productImg.value,
                    description: productDescription.value,
                    price: productPrice.value
                };
                productsArr.push(newProduct);



                let xhrSender = new XMLHttpRequest();
                xhrSender.open('post', 'https://api.npoint.io/ffb62331b1d8fbc9b934', true);

                xhrSender.setRequestHeader('Content-type', 'application/json; charset=utf-8');

                xhrSender.send(JSON.stringify(productsArr)); // не забудь про JSON.stringify()

                xhrSender.addEventListener('readystatechange', function () {
                    if (xhrSender.readyState == 4) {
                        if (xhrSender.status == 200) {
                            alert('Товар успешно добавлен!');
                        } else {
                            alert('Ошибка отправки. Попробуйте еще раз.');
                        }
                    }
                });
            }
        });
    } else {
        alert('Заполните все поля!');
    }
});